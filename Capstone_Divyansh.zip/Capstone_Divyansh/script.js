// Function to check if all required fields in a form are filled out
function isFormValid(formId) {
    var form = document.getElementById(formId);
    var inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    for (var i = 0; i < inputs.length; i++) {
      if (!inputs[i].value) {
        return false;
      }
    }
    return true;
  }
  
  // Function to update the progress bar width
  function updateProgressBar(currentStep, totalSteps) {
    var progressBar = document.getElementById("progressBar");
    var progress = ((currentStep - 1) / totalSteps) * 100;
    progressBar.style.width = progress + "%";
  }
  
  document.getElementById("nextButtonCompanyType").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    var selectedType = document.querySelector('input[name="companyType"]:checked');
    if (selectedType) {
      document.getElementById("companyTypePage").style.display = "none";
      document.getElementById("fundingAmountPage").style.display = "block";
      updateProgressBar(2, 5); // Update progress bar to indicate completion of step 1
    } else {
      alert("Please select your company type.");
    }
  });
  
  document.getElementById("prevButtonFunding").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("fundingAmountPage").style.display = "none";
    document.getElementById("companyTypePage").style.display = "block";
    updateProgressBar(1, 5); // Update progress bar to indicate completion of step 2
  });
  
  document.getElementById("nextButtonFunding").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    if (isFormValid("fundingAmountForm")) {
      document.getElementById("fundingAmountPage").style.display = "none";
      document.getElementById("personalInfoPage").style.display = "block";
      updateProgressBar(3, 5); // Update progress bar to indicate completion of step 2
    } else {
      alert("Please fill out all required fields.");
    }
  });
  
  document.getElementById("prevButtonPersonal").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("personalInfoPage").style.display = "none";
    document.getElementById("fundingAmountPage").style.display = "block";
    updateProgressBar(2, 5); // Update progress bar to indicate completion of step 3
  });
  
  document.getElementById("nextButtonPersonal").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    if (isFormValid("personalInfoForm")) {
      document.getElementById("personalInfoPage").style.display = "none";
      document.getElementById("companyDetailsPage").style.display = "block";
      updateProgressBar(4, 5); // Update progress bar to indicate completion of step 3
    } else {
      alert("Please fill out all required fields.");
    }
  });
  
  document.getElementById("prevButtonCompany").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("companyDetailsPage").style.display = "none";
    document.getElementById("personalInfoPage").style.display = "block";
    updateProgressBar(3, 5); // Update progress bar to indicate completion of step 4
  });
  
  document.getElementById("nextButtonCompany").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    if (isFormValid("companyDetailsForm")) {
      document.getElementById("companyDetailsPage").style.display = "none";
      document.getElementById("creditHistoryPage").style.display = "block";
      updateProgressBar(5, 5); // Update progress bar to indicate completion of step 4
    } else {
      alert("Please fill out all required fields.");
    }
  });
  
  document.getElementById("prevButtonCredit").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("creditHistoryPage").style.display = "none";
    document.getElementById("companyDetailsPage").style.display = "block";
    updateProgressBar(4, 5); // Update progress bar to indicate completion of step 5
  });
  
  document.getElementById("nextButtonCredit").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("creditHistoryPage").style.display = "none";
    document.getElementById("fundsSeekingPage").style.display = "block";
    updateProgressBar(6, 5); // Update progress bar to indicate completion of step 5
  });
  
  document.getElementById("prevButtonFunds").addEventListener("click", function(event) {
    event.preventDefault(); // Prevent form submission
    document.getElementById("fundsSeekingPage").style.display = "none";
    document.getElementById("creditHistoryPage").style.display = "block";
    updateProgressBar(5, 5); // Update progress bar to indicate completion of step 6
  });
  
  document.getElementById("fundsSeekingForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission
    if (isFormValid("fundsSeekingForm")) {
      // Display the thank you message
      const thankYouMessage = document.createElement("p");
      thankYouMessage.textContent = "Thanks for submitting, we will contact you back.";
      document.getElementById("fundsSeekingPage").appendChild(thankYouMessage);
  
      // Reset the form
      document.getElementById("fundsSeekingForm").reset();
  
      // Redirect to the thank you page after a delay (e.g., 2 seconds)
      setTimeout(function() {
        window.location.href = "thankyou.html";
      }, 100); // Change the delay as needed
    } else {
      alert("Please fill out all required fields.");
    }
  });
  